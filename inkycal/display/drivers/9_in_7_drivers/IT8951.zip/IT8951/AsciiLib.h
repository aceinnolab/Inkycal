#ifndef __AsciiLib_H
#define __AsciiLib_H  

#include <stdint.h>
#include <string.h>

void GetASCIICode(uint8_t* pBuffer,uint8_t ASCII);

#endif 

